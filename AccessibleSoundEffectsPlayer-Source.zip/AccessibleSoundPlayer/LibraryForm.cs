namespace AccessibleSoundPlayer;

public sealed class LibraryForm : Form
{
    private readonly ListBox list = new() { AccessibleName = "Assigned sounds", Dock = DockStyle.Fill };
    public List<SoundEntry> Entries { get; private set; }
    public LibraryForm(IEnumerable<SoundEntry> entries)
    {
        Entries = entries.Select(x => new SoundEntry { Code = x.Code, Name = x.Name, Category = x.Category, FilePath = x.FilePath }).ToList();
        Text = "Sound Library"; AccessibleName = Text; StartPosition = FormStartPosition.CenterParent; MinimumSize = new Size(720, 500); KeyPreview = true;
        var buttons = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 80, Padding = new Padding(8) };
        AddButton(buttons, "&Add...", (_, _) => AddOne()); AddButton(buttons, "&Import folder...", (_, _) => ImportFolder()); AddButton(buttons, "&Edit...", (_, _) => Edit()); AddButton(buttons, "&Delete", (_, _) => Delete()); AddButton(buttons, "&Save and close", (_, _) => { DialogResult = DialogResult.OK; Close(); }); AddButton(buttons, "Cancel", (_, _) => Close());
        Controls.Add(list); Controls.Add(buttons); RefreshList();
        list.DoubleClick += (_, _) => Edit();
        KeyDown += (_, e) => { if (e.KeyCode == Keys.Delete) { Delete(); e.Handled = true; } };
    }
    private static void AddButton(Control parent, string text, EventHandler action) { var b = new Button { Text = text, AutoSize = true }; b.Click += action; parent.Controls.Add(b); }
    private void AddOne()
    {
        using var pick = new OpenFileDialog { Title = "Choose a sound file", Filter = "Audio files|*.wav;*.mp3;*.wma;*.aac;*.m4a;*.aiff;*.flac|All files|*.*" };
        if (pick.ShowDialog(this) != DialogResult.OK) return;
        var next = NextCode();
        using var editor = new SoundEntryForm(new SoundEntry { Code = next, Name = Path.GetFileNameWithoutExtension(pick.FileName), FilePath = pick.FileName });
        if (editor.ShowDialog(this) == DialogResult.OK && ValidateEntry(editor.Value, null)) { Entries.Add(editor.Value); RefreshList(); }
    }
    private void ImportFolder()
    {
        using var pick = new FolderBrowserDialog { Description = "Choose a folder containing sound effects", UseDescriptionForTitle = true };
        if (pick.ShowDialog(this) != DialogResult.OK) return;
        var extensions = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { ".wav", ".mp3", ".wma", ".aac", ".m4a", ".aiff", ".flac" };
        var files = Directory.EnumerateFiles(pick.SelectedPath).Where(x => extensions.Contains(Path.GetExtension(x))).OrderBy(x => x).ToList();
        if (files.Count == 0) { MessageBox.Show(this, "That folder contains no supported audio files.", "Import folder"); return; }
        var category = Path.GetFileName(pick.SelectedPath);
        var added = 0;
        foreach (var file in files)
        {
            var code = NextCode(); if (code == "") break;
            Entries.Add(new SoundEntry { Code = code, Name = Path.GetFileNameWithoutExtension(file), Category = category, FilePath = file }); added++;
        }
        RefreshList(); MessageBox.Show(this, $"Imported {added} sounds. They were assigned the next available codes and category {category}. You can edit any entry.", "Import complete");
    }
    private void Edit()
    {
        if (list.SelectedItem is not SoundEntry selected) { MessageBox.Show(this, "Select a sound first.", "Edit sound"); return; }
        using var editor = new SoundEntryForm(new SoundEntry { Code = selected.Code, Name = selected.Name, Category = selected.Category, FilePath = selected.FilePath });
        if (editor.ShowDialog(this) == DialogResult.OK && ValidateEntry(editor.Value, selected)) { var index = Entries.IndexOf(selected); Entries[index] = editor.Value; RefreshList(editor.Value); }
    }
    private bool ValidateEntry(SoundEntry entry, SoundEntry? original)
    {
        if (entry.Code.Length != 3 || !entry.Code.All(char.IsDigit)) { MessageBox.Show(this, "The code must contain exactly three digits.", "Invalid code"); return false; }
        if (Entries.Any(x => !ReferenceEquals(x, original) && x.Code == entry.Code)) { MessageBox.Show(this, $"Code {entry.Code} is already assigned.", "Duplicate code"); return false; }
        if (string.IsNullOrWhiteSpace(entry.Name) || string.IsNullOrWhiteSpace(entry.FilePath)) { MessageBox.Show(this, "Name and file are required.", "Missing information"); return false; }
        return true;
    }
    private void Delete()
    {
        if (list.SelectedItem is not SoundEntry selected) return;
        if (MessageBox.Show(this, $"Remove code {selected.Code}, {selected.Name}, from the library? The audio file will not be deleted.", "Confirm removal", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes) { Entries.Remove(selected); RefreshList(); }
    }
    private string NextCode()
    {
        for (var i = 0; i <= 999; i++) { var code = i.ToString("000"); if (Entries.All(x => x.Code != code)) return code; }
        return "";
    }
    private void RefreshList(SoundEntry? select = null) { list.DataSource = null; list.DataSource = Entries.OrderBy(x => x.Code).ToList(); if (select is not null) list.SelectedItem = select; }
}

public sealed class SoundEntryForm : Form
{
    private readonly TextBox code = new() { MaxLength = 3, Width = 80 };
    private readonly TextBox name = new() { Width = 420 };
    private readonly TextBox category = new() { Width = 420 };
    private readonly TextBox file = new() { Width = 420 };
    public SoundEntry Value => new() { Code = code.Text, Name = name.Text.Trim(), Category = string.IsNullOrWhiteSpace(category.Text) ? "Uncategorized" : category.Text.Trim(), FilePath = file.Text };
    public SoundEntryForm(SoundEntry value)
    {
        Text = "Sound information"; StartPosition = FormStartPosition.CenterParent; AutoSize = true; AutoSizeMode = AutoSizeMode.GrowAndShrink;
        code.Text = value.Code; name.Text = value.Name; category.Text = value.Category; file.Text = value.FilePath;
        code.AccessibleName = "Three-digit code"; name.AccessibleName = "Sound name"; category.AccessibleName = "Category"; file.AccessibleName = "Audio file path";
        code.KeyPress += (_, e) => { if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar)) e.Handled = true; };
        var table = new TableLayoutPanel { AutoSize = true, Padding = new Padding(12), ColumnCount = 3 };
        AddRow(table, "&Code:", code); AddRow(table, "&Name:", name); AddRow(table, "C&ategory:", category); AddRow(table, "&File:", file);
        var browse = new Button { Text = "&Browse...", AutoSize = true }; browse.Click += (_, _) => Browse(); table.Controls.Add(browse, 2, 3);
        var ok = new Button { Text = "&OK", DialogResult = DialogResult.OK, AutoSize = true }; var cancel = new Button { Text = "Cancel", DialogResult = DialogResult.Cancel, AutoSize = true };
        table.Controls.Add(ok, 1, 4); table.Controls.Add(cancel, 2, 4); Controls.Add(table); AcceptButton = ok; CancelButton = cancel;
    }
    private static void AddRow(TableLayoutPanel table, string label, Control control) { var row = table.RowCount++; var l = new Label { Text = label, AutoSize = true, TextAlign = ContentAlignment.MiddleLeft, TabStop = false }; table.Controls.Add(l, 0, row); table.Controls.Add(control, 1, row); }
    private void Browse() { using var pick = new OpenFileDialog { Filter = "Audio files|*.wav;*.mp3;*.wma;*.aac;*.m4a;*.aiff;*.flac|All files|*.*" }; if (pick.ShowDialog(this) == DialogResult.OK) file.Text = pick.FileName; }
}
