namespace AccessibleSoundPlayer;

public sealed class LibraryForm : Form
{
    private readonly ListBox list = new() { AccessibleName = "Assigned sounds", Dock = DockStyle.Fill };
    private readonly ComboBox setPicker = new() { DropDownStyle = ComboBoxStyle.DropDownList, AccessibleName = "Sound set to manage", Width = 140 };
    private readonly ComboBox bankPicker = new() { DropDownStyle = ComboBoxStyle.DropDownList, AccessibleName = "Bank to manage", Width = 200 };
    public List<SoundEntry> Entries { get; private set; }
    public Dictionary<string, string> BankNames { get; }
    public int SelectedSet => setPicker.SelectedIndex + 1;
    public int SelectedBank => bankPicker.SelectedIndex;
    public LibraryForm(IEnumerable<SoundEntry> entries, int initialSet, int initialBank, Dictionary<string, string>? bankNames)
    {
        Entries = entries.Select(x => new SoundEntry { SetNumber = x.SetNumber is >= 1 and <= 2 ? x.SetNumber : 1, Bank = x.Bank is >= 0 and <= 9 ? x.Bank : 1, Code = x.Code, Name = x.Name, Category = x.Category, FilePath = x.FilePath, Played = x.Played }).ToList();
        BankNames = new Dictionary<string, string>(bankNames ?? new());
        Text = "Sound Library"; AccessibleName = Text; StartPosition = FormStartPosition.CenterParent; MinimumSize = new Size(720, 500); KeyPreview = true;
        var bankBar = new FlowLayoutPanel { Dock = DockStyle.Top, AutoSize = true, Padding = new Padding(8) };
        bankBar.Controls.Add(new Label { Text = "&Set:", AutoSize = true, TextAlign = ContentAlignment.MiddleLeft });
        setPicker.Items.Add("Set 1, F2"); setPicker.Items.Add("Set 2, F3");
        setPicker.SelectedIndex = Math.Clamp(initialSet, 1, 2) - 1;
        bankBar.Controls.Add(setPicker);
        bankBar.Controls.Add(new Label { Text = "&Bank:", AutoSize = true, TextAlign = ContentAlignment.MiddleLeft });
        bankBar.Controls.Add(bankPicker);
        RefreshBankItems(initialBank);
        setPicker.SelectedIndexChanged += (_, _) => RefreshBankItems();
        bankPicker.SelectedIndexChanged += (_, _) => { if (SelectedBank >= 0) RefreshList(); };
        var buttons = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 110, Padding = new Padding(8) };
        AddButton(buttons, "&Add...", (_, _) => AddOne()); AddButton(buttons, "&Import folder...", (_, _) => ImportFolder()); AddButton(buttons, "&Edit...", (_, _) => Edit()); AddButton(buttons, "&Delete", (_, _) => Delete()); AddButton(buttons, "&Rename bank...", (_, _) => RenameBank()); AddButton(buttons, "&Save and close", (_, _) => { DialogResult = DialogResult.OK; Close(); }); AddButton(buttons, "Cancel", (_, _) => Close());
        Controls.Add(list); Controls.Add(bankBar); Controls.Add(buttons); RefreshList();
        list.DoubleClick += (_, _) => Edit();
        KeyDown += (_, e) => { if (e.KeyCode == Keys.Delete) { Delete(); e.Handled = true; } };
    }
    private static void AddButton(Control parent, string text, EventHandler action) { var b = new Button { Text = text, AutoSize = true }; b.Click += action; parent.Controls.Add(b); }
    private void AddOne()
    {
        using var pick = new OpenFileDialog { Title = "Choose a sound file", Filter = "Audio files|*.wav;*.mp3;*.wma;*.aac;*.m4a;*.aiff;*.flac|All files|*.*" };
        if (pick.ShowDialog(this) != DialogResult.OK) return;
        var next = NextCode();
        if (next == "") { MessageBox.Show(this, $"Set {SelectedSet}, {GetBankDisplayName(SelectedSet, SelectedBank)} has no available four-digit codes.", "Bank full"); return; }
        using var editor = new SoundEntryForm(new SoundEntry { SetNumber = SelectedSet, Bank = SelectedBank, Code = next, Name = Path.GetFileNameWithoutExtension(pick.FileName), FilePath = pick.FileName });
        if (editor.ShowDialog(this) == DialogResult.OK && ValidateEntry(editor.Value, null)) { Entries.Add(editor.Value); RefreshList(); }
    }
    private void ImportFolder()
    {
        using var pick = new FolderBrowserDialog { Description = "Choose a folder containing sound effects", UseDescriptionForTitle = true };
        if (pick.ShowDialog(this) != DialogResult.OK) return;
        var extensions = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { ".wav", ".mp3", ".wma", ".aac", ".m4a", ".aiff", ".flac" };
        var files = Directory.EnumerateFiles(pick.SelectedPath).Where(x => extensions.Contains(Path.GetExtension(x))).OrderBy(x => x).ToList();
        if (files.Count == 0) { MessageBox.Show(this, "That folder contains no supported audio files.", "Import folder"); return; }
        var category = Path.GetFileName(pick.SelectedPath);
        var added = 0;
        foreach (var file in files)
        {
            var code = NextCode(); if (code == "") break;
            Entries.Add(new SoundEntry { SetNumber = SelectedSet, Bank = SelectedBank, Code = code, Name = Path.GetFileNameWithoutExtension(file), Category = category, FilePath = file }); added++;
        }
        RefreshList(); MessageBox.Show(this, $"Imported {added} sounds. They were assigned the next available codes and category {category}. You can edit any entry.", "Import complete");
    }
    private void Edit()
    {
        if (list.SelectedItem is not SoundEntry selected) { MessageBox.Show(this, "Select a sound first.", "Edit sound"); return; }
        using var editor = new SoundEntryForm(new SoundEntry { SetNumber = selected.SetNumber, Bank = selected.Bank, Code = selected.Code, Name = selected.Name, Category = selected.Category, FilePath = selected.FilePath, Played = selected.Played });
        if (editor.ShowDialog(this) == DialogResult.OK && ValidateEntry(editor.Value, selected)) { var index = Entries.IndexOf(selected); Entries[index] = editor.Value; RefreshList(editor.Value); }
    }
    private bool ValidateEntry(SoundEntry entry, SoundEntry? original)
    {
        if (entry.Code.Length != 4 || !entry.Code.All(char.IsDigit)) { MessageBox.Show(this, "The code must contain exactly four digits.", "Invalid code"); return false; }
        if (Entries.Any(x => !ReferenceEquals(x, original) && x.SetNumber == entry.SetNumber && x.Bank == entry.Bank && x.Code == entry.Code)) { MessageBox.Show(this, $"Code {entry.Code} is already assigned in set {entry.SetNumber}, {GetBankDisplayName(entry.SetNumber, entry.Bank)}.", "Duplicate code"); return false; }
        if (string.IsNullOrWhiteSpace(entry.Name) || string.IsNullOrWhiteSpace(entry.FilePath)) { MessageBox.Show(this, "Name and file are required.", "Missing information"); return false; }
        return true;
    }
    private void Delete()
    {
        if (list.SelectedItem is not SoundEntry selected) return;
        if (MessageBox.Show(this, $"Remove set {selected.SetNumber}, {GetBankDisplayName(selected.SetNumber, selected.Bank)}, code {selected.Code}, {selected.Name}, from the library? The audio file will not be deleted.", "Confirm removal", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes) { Entries.Remove(selected); RefreshList(); }
    }
    private string NextCode()
    {
        for (var i = 0; i <= 9999; i++) { var code = i.ToString("0000"); if (Entries.All(x => x.SetNumber != SelectedSet || x.Bank != SelectedBank || x.Code != code)) return code; }
        return "";
    }
    private void RefreshBankItems(int preferredBank = -1)
    {
        var bank = preferredBank is >= 0 and <= 9 ? preferredBank : Math.Max(bankPicker.SelectedIndex, 0);
        bankPicker.DataSource = null;
        bankPicker.Items.Clear();
        for (var number = 0; number <= 9; number++) bankPicker.Items.Add(GetBankDisplayName(SelectedSet, number));
        bankPicker.SelectedIndex = Math.Clamp(bank, 0, 9);
        RefreshList();
    }
    private void RenameBank()
    {
        using var form = new BankNameForm(SelectedSet, SelectedBank, GetBankName(SelectedSet, SelectedBank));
        if (form.ShowDialog(this) != DialogResult.OK) return;
        SetBankName(SelectedSet, SelectedBank, form.BankName);
        RefreshBankItems(SelectedBank);
    }
    private string GetBankName(int setNumber, int bank)
    {
        var key = $"{setNumber}:{bank}";
        return BankNames.TryGetValue(key, out var name) && !string.IsNullOrWhiteSpace(name) ? name.Trim() : "";
    }
    private string GetBankDisplayName(int setNumber, int bank)
    {
        var name = GetBankName(setNumber, bank);
        return string.IsNullOrEmpty(name) ? $"Bank {bank}" : $"Bank {bank}: {name}";
    }
    private void SetBankName(int setNumber, int bank, string name)
    {
        var key = $"{setNumber}:{bank}";
        if (string.IsNullOrWhiteSpace(name)) BankNames.Remove(key);
        else BankNames[key] = name.Trim();
    }
    private void RefreshList(SoundEntry? select = null) { list.AccessibleName = $"Assigned sounds in set {SelectedSet}, {GetBankDisplayName(SelectedSet, SelectedBank)}"; list.DataSource = null; list.DataSource = Entries.Where(x => x.SetNumber == SelectedSet && x.Bank == SelectedBank).OrderBy(x => x.Code).ToList(); if (select is not null) list.SelectedItem = select; }
}

public sealed class SoundEntryForm : Form
{
    private readonly int setNumber;
    private readonly int bank;
    private readonly TextBox code = new() { MaxLength = 4, Width = 90 };
    private readonly TextBox name = new() { Width = 420 };
    private readonly TextBox category = new() { Width = 420 };
    private readonly TextBox file = new() { Width = 420 };
    private readonly bool played;
    public SoundEntry Value => new() { SetNumber = setNumber, Bank = bank, Code = code.Text, Name = name.Text.Trim(), Category = string.IsNullOrWhiteSpace(category.Text) ? "Uncategorized" : category.Text.Trim(), FilePath = file.Text, Played = played };
    public SoundEntryForm(SoundEntry value)
    {
        setNumber = value.SetNumber;
        bank = value.Bank;
        played = value.Played;
        Text = $"Sound information - set {setNumber}, bank {bank}"; StartPosition = FormStartPosition.CenterParent; AutoSize = true; AutoSizeMode = AutoSizeMode.GrowAndShrink;
        code.Text = value.Code; name.Text = value.Name; category.Text = value.Category; file.Text = value.FilePath;
        code.AccessibleName = "Four-digit code"; name.AccessibleName = "Sound name"; category.AccessibleName = "Category"; file.AccessibleName = "Audio file path";
        code.KeyPress += (_, e) => { if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar)) e.Handled = true; };
        var table = new TableLayoutPanel { AutoSize = true, Padding = new Padding(12), ColumnCount = 3 };
        AddRow(table, "&Code:", code); AddRow(table, "&Name:", name); AddRow(table, "C&ategory:", category); AddRow(table, "&File:", file);
        var browse = new Button { Text = "&Browse...", AutoSize = true }; browse.Click += (_, _) => Browse(); table.Controls.Add(browse, 2, 3);
        var ok = new Button { Text = "&OK", DialogResult = DialogResult.OK, AutoSize = true }; var cancel = new Button { Text = "Cancel", DialogResult = DialogResult.Cancel, AutoSize = true };
        table.Controls.Add(ok, 1, 4); table.Controls.Add(cancel, 2, 4); Controls.Add(table); AcceptButton = ok; CancelButton = cancel;
    }
    private static void AddRow(TableLayoutPanel table, string label, Control control) { var row = table.RowCount++; var l = new Label { Text = label, AutoSize = true, TextAlign = ContentAlignment.MiddleLeft, TabStop = false }; table.Controls.Add(l, 0, row); table.Controls.Add(control, 1, row); }
    private void Browse() { using var pick = new OpenFileDialog { Filter = "Audio files|*.wav;*.mp3;*.wma;*.aac;*.m4a;*.aiff;*.flac|All files|*.*" }; if (pick.ShowDialog(this) == DialogResult.OK) file.Text = pick.FileName; }
}

public sealed class BankNameForm : Form
{
    private readonly TextBox name = new() { Width = 360, MaxLength = 80, AccessibleName = "Bank name" };
    public string BankName => name.Text.Trim();

    public BankNameForm(int setNumber, int bank, string currentName)
    {
        Text = $"Name set {setNumber}, bank {bank}";
        AccessibleName = Text;
        StartPosition = FormStartPosition.CenterParent;
        AutoSize = true;
        AutoSizeMode = AutoSizeMode.GrowAndShrink;
        name.Text = currentName;
        var table = new TableLayoutPanel { AutoSize = true, Padding = new Padding(12), ColumnCount = 2 };
        table.Controls.Add(new Label { Text = "Bank &name:", AutoSize = true, TextAlign = ContentAlignment.MiddleLeft }, 0, 0);
        table.Controls.Add(name, 1, 0);
        var save = new Button { Text = "&Save", DialogResult = DialogResult.OK, AutoSize = true };
        var clear = new Button { Text = "&Clear name", AutoSize = true };
        clear.Click += (_, _) => name.Clear();
        var cancel = new Button { Text = "Cancel", DialogResult = DialogResult.Cancel, AutoSize = true };
        var buttons = new FlowLayoutPanel { AutoSize = true };
        buttons.Controls.Add(save); buttons.Controls.Add(clear); buttons.Controls.Add(cancel);
        table.Controls.Add(buttons, 1, 1);
        Controls.Add(table);
        AcceptButton = save;
        CancelButton = cancel;
        Shown += (_, _) => { name.Focus(); name.SelectAll(); };
    }
}
