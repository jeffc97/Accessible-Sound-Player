using NAudio.Wave;

namespace AccessibleSoundPlayer;

public sealed class AudioPlayer : IDisposable
{
    private readonly List<(WaveOutEvent Output, AudioFileReader Reader)> active = new();

    public static IReadOnlyList<(int Number, string Name)> GetDevices()
    {
        var result = new List<(int, string)> { (-1, "Windows default output") };
        for (var i = 0; i < WaveOut.DeviceCount; i++) result.Add((i, WaveOut.GetCapabilities(i).ProductName));
        return result;
    }

    public void Play(string path, AppSettings settings)
    {
        Stop();
        var devices = new List<int>();
        if (settings.UseMeeting) devices.Add(settings.MeetingDevice);
        if (settings.UseHeadphones && !devices.Contains(settings.HeadphoneDevice)) devices.Add(settings.HeadphoneDevice);
        if (devices.Count == 0) throw new InvalidOperationException("No output is enabled. Open Audio settings with Alt+O.");
        foreach (var device in devices)
        {
            var reader = new AudioFileReader(path) { Volume = settings.Volume };
            var output = new WaveOutEvent { DeviceNumber = device };
            output.Init(reader);
            active.Add((output, reader));
            output.Play();
        }
    }

    public void Stop()
    {
        foreach (var item in active.ToArray()) { try { item.Output.Stop(); } catch { } item.Output.Dispose(); item.Reader.Dispose(); }
        active.Clear();
    }
    public void Dispose() => Stop();
}
