#define MyAppName "Accessible Sound Effects Player"
#define MyAppVersion "1.4.0"
#define MyAppExeName "AccessibleSoundPlayer.exe"
[Setup]
AppId={{C20A8519-F791-4C7C-9773-76B813948C32}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
DefaultDirName={autopf}\Accessible Sound Effects Player
DefaultGroupName={#MyAppName}
OutputDir=installer-output
OutputBaseFilename=AccessibleSoundEffectsPlayer-Setup
Compression=lzma2
SolidCompression=yes
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
PrivilegesRequired=lowest
WizardStyle=modern
[Files]
Source: "publish\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon
[Tasks]
Name: "desktopicon"; Description: "Create a &desktop shortcut"; GroupDescription: "Additional shortcuts:"
[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Launch {#MyAppName}"; Flags: nowait postinstall skipifsilent
