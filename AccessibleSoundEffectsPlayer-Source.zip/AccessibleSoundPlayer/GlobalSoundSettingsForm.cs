namespace AccessibleSoundPlayer;

public sealed class GlobalSoundSettingsForm : Form
{
    private readonly TextBox aFile = NewPathBox("A key sound file");
    private readonly TextBox sFile = NewPathBox("S key sound file");
    private readonly TextBox dFile = NewPathBox("D key sound file");
    private readonly TextBox fFile = NewPathBox("F key sound file");
    private readonly TextBox zFile = NewPathBox("Z key sound file");
    private readonly TextBox xFile = NewPathBox("X key sound file");
    private readonly TextBox cFile = NewPathBox("C key sound file");
    private readonly AppSettings value;

    public AppSettings Value
    {
        get
        {
            value.GlobalAFile = aFile.Text;
            value.GlobalSFile = sFile.Text;
            value.GlobalDFile = dFile.Text;
            value.GlobalFFile = fFile.Text;
            value.GlobalZFile = zFile.Text;
            value.GlobalXFile = xFile.Text;
            value.GlobalCFile = cFile.Text;
            return value;
        }
    }

    public GlobalSoundSettingsForm(AppSettings settings)
    {
        value = settings.Clone();
        Text = "Global sound hot keys";
        AccessibleName = Text;
        StartPosition = FormStartPosition.CenterParent;
        AutoSize = true;
        AutoSizeMode = AutoSizeMode.GrowAndShrink;

        aFile.Text = settings.GlobalAFile;
        sFile.Text = settings.GlobalSFile;
        dFile.Text = settings.GlobalDFile;
        fFile.Text = settings.GlobalFFile;
        zFile.Text = settings.GlobalZFile;
        xFile.Text = settings.GlobalXFile;
        cFile.Text = settings.GlobalCFile;

        var table = new TableLayoutPanel { AutoSize = true, Padding = new Padding(12), ColumnCount = 4, RowCount = 1 };
        var introduction = new Label { Text = "Choose sounds for A, S, D, F, Z, X, and C. These global keys work immediately in every set and bank.", AutoSize = true };
        table.Controls.Add(introduction, 0, 0);
        table.SetColumnSpan(introduction, 4);
        AddSoundRow(table, "A key sound:", aFile, "Choose &A...", "Clear A", () => Browse(aFile));
        AddSoundRow(table, "S key sound:", sFile, "Choose &S...", "Clear S", () => Browse(sFile));
        AddSoundRow(table, "D key sound:", dFile, "Choose &D...", "Clear D", () => Browse(dFile));
        AddSoundRow(table, "F key sound:", fFile, "Choose &F...", "Clear F", () => Browse(fFile));
        AddSoundRow(table, "Z key sound:", zFile, "Choose &Z...", "Clear Z", () => Browse(zFile));
        AddSoundRow(table, "X key sound:", xFile, "Choose &X...", "Clear X", () => Browse(xFile));
        AddSoundRow(table, "C key sound:", cFile, "Choose &C...", "Clear C", () => Browse(cFile));

        var ok = new Button { Text = "&Save", DialogResult = DialogResult.OK, AutoSize = true };
        var cancel = new Button { Text = "Cancel", DialogResult = DialogResult.Cancel, AutoSize = true };
        var buttons = new FlowLayoutPanel { AutoSize = true };
        buttons.Controls.Add(ok);
        buttons.Controls.Add(cancel);
        table.Controls.Add(buttons, 1, table.RowCount);
        table.SetColumnSpan(buttons, 3);
        Controls.Add(table);
        AcceptButton = ok;
        CancelButton = cancel;
    }

    private static TextBox NewPathBox(string accessibleName) => new() { Width = 440, ReadOnly = true, AccessibleName = accessibleName };

    private static void AddSoundRow(TableLayoutPanel table, string label, TextBox path, string chooseText, string clearText, Action choose)
    {
        var row = table.RowCount++;
        table.Controls.Add(new Label { Text = label, AutoSize = true, TextAlign = ContentAlignment.MiddleLeft }, 0, row);
        table.Controls.Add(path, 1, row);
        var chooseButton = new Button { Text = chooseText, AutoSize = true };
        chooseButton.Click += (_, _) => choose();
        var clearButton = new Button { Text = clearText, AutoSize = true, AccessibleName = clearText + " assignment" };
        clearButton.Click += (_, _) => path.Clear();
        table.Controls.Add(chooseButton, 2, row);
        table.Controls.Add(clearButton, 3, row);
    }

    private void Browse(TextBox destination)
    {
        using var pick = new OpenFileDialog
        {
            Title = "Choose a sound file",
            Filter = "Audio files|*.wav;*.mp3;*.wma;*.aac;*.m4a;*.aiff;*.flac|All files|*.*"
        };
        if (pick.ShowDialog(this) == DialogResult.OK) destination.Text = pick.FileName;
    }
}
