using System.Text.Json;

namespace AccessibleSoundPlayer;

public sealed class SoundEntry
{
    // Existing sounds.json files have no Bank property and therefore load into bank 1.
    public int Bank { get; set; } = 1;
    public string Code { get; set; } = "0000";
    public string Name { get; set; } = "";
    public string Category { get; set; } = "Uncategorized";
    public string FilePath { get; set; } = "";
    public override string ToString() => $"{Code}: {Name}; category {Category}";
}

public sealed class AppSettings
{
    public int ActiveBank { get; set; } = 1;
    public string GlobalZFile { get; set; } = "";
    public string GlobalXFile { get; set; } = "";
    public string GlobalCFile { get; set; } = "";
    public int MeetingDevice { get; set; } = -1;
    public int HeadphoneDevice { get; set; } = -1;
    public bool UseMeeting { get; set; } = true;
    public bool UseHeadphones { get; set; } = true;
    public float Volume { get; set; } = 1f;
}

public static class AppData
{
    public static readonly string Folder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Accessible Sound Effects Player");
    public static readonly string LibraryPath = Path.Combine(Folder, "sounds.json");
    public static readonly string SettingsPath = Path.Combine(Folder, "settings.json");
    private static readonly JsonSerializerOptions JsonOptions = new() { WriteIndented = true };

    public static List<SoundEntry> LoadLibrary()
    {
        var entries = Load(LibraryPath, new List<SoundEntry>());
        // Preserve older assignments by converting 000 through 999 to
        // 0000 through 0999 when the expanded code system is first loaded.
        foreach (var entry in entries)
            if (entry.Code.Length == 3 && entry.Code.All(char.IsDigit)) entry.Code = entry.Code.PadLeft(4, '0');
        return entries;
    }
    public static AppSettings LoadSettings() => Load(SettingsPath, new AppSettings());
    public static void SaveLibrary(List<SoundEntry> value) => Save(LibraryPath, value);
    public static void SaveSettings(AppSettings value) => Save(SettingsPath, value);

    private static T Load<T>(string path, T fallback)
    {
        try { return File.Exists(path) ? JsonSerializer.Deserialize<T>(File.ReadAllText(path)) ?? fallback : fallback; }
        catch { return fallback; }
    }
    private static void Save<T>(string path, T value)
    {
        Directory.CreateDirectory(Folder);
        File.WriteAllText(path, JsonSerializer.Serialize(value, JsonOptions));
    }
}
