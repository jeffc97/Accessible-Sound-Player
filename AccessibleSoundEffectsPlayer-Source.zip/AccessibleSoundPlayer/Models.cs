using System.Text.Json;

namespace AccessibleSoundPlayer;

public sealed class SoundEntry
{
    public string Code { get; set; } = "000";
    public string Name { get; set; } = "";
    public string Category { get; set; } = "Uncategorized";
    public string FilePath { get; set; } = "";
    public override string ToString() => $"{Code}: {Name}; category {Category}";
}

public sealed class AppSettings
{
    public int MeetingDevice { get; set; } = -1;
    public int HeadphoneDevice { get; set; } = -1;
    public bool UseMeeting { get; set; } = true;
    public bool UseHeadphones { get; set; } = true;
    public float Volume { get; set; } = 1f;
}

public static class AppData
{
    public static readonly string Folder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Accessible Sound Effects Player");
    public static readonly string LibraryPath = Path.Combine(Folder, "sounds.json");
    public static readonly string SettingsPath = Path.Combine(Folder, "settings.json");
    private static readonly JsonSerializerOptions JsonOptions = new() { WriteIndented = true };

    public static List<SoundEntry> LoadLibrary() => Load(LibraryPath, new List<SoundEntry>());
    public static AppSettings LoadSettings() => Load(SettingsPath, new AppSettings());
    public static void SaveLibrary(List<SoundEntry> value) => Save(LibraryPath, value);
    public static void SaveSettings(AppSettings value) => Save(SettingsPath, value);

    private static T Load<T>(string path, T fallback)
    {
        try { return File.Exists(path) ? JsonSerializer.Deserialize<T>(File.ReadAllText(path)) ?? fallback : fallback; }
        catch { return fallback; }
    }
    private static void Save<T>(string path, T value)
    {
        Directory.CreateDirectory(Folder);
        File.WriteAllText(path, JsonSerializer.Serialize(value, JsonOptions));
    }
}
