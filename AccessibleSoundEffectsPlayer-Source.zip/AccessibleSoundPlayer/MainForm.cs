using System.Windows.Forms.Automation;

namespace AccessibleSoundPlayer;

public sealed class MainForm : Form
{
    private readonly TextBox codeBox = new() { MaxLength = 4, AccessibleName = "Four-digit sound code", Font = new Font("Segoe UI", 22), Width = 180 };
    private readonly Label status = new() { AutoSize = true, AccessibleName = "Player status" };
    private readonly Label bankLabel = new() { AutoSize = true };
    private readonly ListBox sounds = new() { AccessibleName = "Available sounds", IntegralHeight = false };
    private readonly AudioPlayer player = new();
    private List<SoundEntry> library = AppData.LoadLibrary();
    private AppSettings settings = AppData.LoadSettings();
    private string? lastPlayedPath;
    private string? lastPlayedDescription;
    private bool awaitingBankNumber;
    private bool awaitingRenameBankNumber;
    private bool awaitingTransferSourceBank;
    private bool awaitingTransferDestinationBank;
    private int transferSourceBank = -1;
    private int activeSet => Math.Clamp(settings.ActiveSet, 1, 2);
    private int activeBank => Math.Clamp(settings.ActiveBank, 0, 9);
    private string activeBankDisplay => settings.GetBankDisplayName(activeSet, activeBank);

    public MainForm()
    {
        Text = "Accessible Sound Effects Player";
        AccessibleName = Text;
        StartPosition = FormStartPosition.CenterScreen;
        MinimumSize = new Size(650, 480);
        KeyPreview = true;
        var menu = BuildMenu();
        var codeLabel = new Label { Text = "Sound code (4 digits):", AutoSize = true, AccessibleName = "Sound code, four digits" };
        var instruction = new Label { Text = "Type four digits. The assigned sound plays automatically.", AutoSize = true };
        var top = new FlowLayoutPanel { Dock = DockStyle.Top, AutoSize = true, FlowDirection = FlowDirection.TopDown, Padding = new Padding(12), WrapContents = false };
        top.Controls.Add(instruction); top.Controls.Add(bankLabel); top.Controls.Add(codeLabel); top.Controls.Add(codeBox); top.Controls.Add(status);
        sounds.Dock = DockStyle.Fill;
        Controls.Add(sounds); Controls.Add(top); Controls.Add(menu);
        MainMenuStrip = menu;
        codeBox.KeyPress += CodeKeyPress;
        codeBox.TextChanged += CodeChanged;
        sounds.DoubleClick += (_, _) => PlaySelected();
        KeyDown += GlobalKeys;
        Shown += (_, _) =>
        {
            RefreshList(); codeBox.Focus();
            var assigned = library.Count(x => x.SetNumber == activeSet && x.Bank == activeBank);
            Announce(assigned == 0 ? $"Set {activeSet}, {activeBankDisplay}. No sounds assigned. Press Control+L to open the Sound Library." : $"Set {activeSet}, {activeBankDisplay} ready. Enter four digits, press F2 or F3 to change sets, or type B followed by 0 through 9 to change banks.");
        };
        FormClosing += (_, _) => player.Dispose();
    }

    private MenuStrip BuildMenu()
    {
        var menu = new MenuStrip();
        var file = new ToolStripMenuItem("&File");
        ((ToolStripMenuItem)file.DropDownItems.Add("&Sound Library...", null, (_, _) => OpenLibrary())).ShortcutKeys = Keys.Control | Keys.L;
        ((ToolStripMenuItem)file.DropDownItems.Add("&Exit", null, (_, _) => Close())).ShortcutKeys = Keys.Alt | Keys.F4;
        var playback = new ToolStripMenuItem("&Playback");
        playback.DropDownItems.Add("&Stop", null, (_, _) => StopPlayback());
        ((ToolStripMenuItem)playback.DropDownItems.Add("&Replay last sound", null, (_, _) => Replay())).ShortcutKeys = Keys.Control | Keys.R;
        var options = new ToolStripMenuItem("&Options");
        ((ToolStripMenuItem)options.DropDownItems.Add("&Audio outputs...", null, (_, _) => OpenAudioSettings())).ShortcutKeys = Keys.Alt | Keys.O;
        ((ToolStripMenuItem)options.DropDownItems.Add("Global sound &hot keys...", null, (_, _) => OpenGlobalSoundSettings())).ShortcutKeys = Keys.Control | Keys.G;
        var help = new ToolStripMenuItem("&Help");
        ((ToolStripMenuItem)help.DropDownItems.Add("&Keyboard commands", null, (_, _) => ShowHelp())).ShortcutKeys = Keys.F1;
        menu.Items.AddRange([file, playback, options, help]);
        return menu;
    }

    private void CodeKeyPress(object? sender, KeyPressEventArgs e)
    {
        if (awaitingTransferSourceBank)
        {
            awaitingTransferSourceBank = false;
            e.Handled = true;
            if (e.KeyChar is >= '0' and <= '9')
            {
                transferSourceBank = e.KeyChar - '0';
                var assigned = library.Count(x => x.SetNumber == activeSet && x.Bank == transferSourceBank);
                if (assigned == 0)
                {
                    transferSourceBank = -1;
                    System.Media.SystemSounds.Beep.Play();
                    Announce($"Transfer canceled. Set {activeSet}, bank {e.KeyChar} has no assigned sounds.");
                }
                else
                {
                    awaitingTransferDestinationBank = true;
                    Announce($"Set {activeSet}, bank {transferSourceBank} contains {assigned} sounds. Which empty bank would you like to move it to? Press 0 through 9.");
                }
            }
            else
            {
                transferSourceBank = -1;
                System.Media.SystemSounds.Beep.Play();
                Announce("Transfer canceled. After T, type a source bank number from 0 through 9.");
            }
            return;
        }
        if (awaitingTransferDestinationBank)
        {
            awaitingTransferDestinationBank = false;
            e.Handled = true;
            if (e.KeyChar is >= '0' and <= '9') MoveBank(transferSourceBank, e.KeyChar - '0');
            else
            {
                System.Media.SystemSounds.Beep.Play();
                Announce("Transfer canceled. The destination must be a bank number from 0 through 9.");
            }
            transferSourceBank = -1;
            return;
        }
        if (awaitingRenameBankNumber)
        {
            awaitingRenameBankNumber = false;
            e.Handled = true;
            if (e.KeyChar is >= '0' and <= '9') RenameBank(e.KeyChar - '0');
            else
            {
                System.Media.SystemSounds.Beep.Play();
                Announce($"Rename canceled. After B then R, type a bank number from 0 through 9. Current set: {activeSet}.");
            }
            return;
        }
        if (e.KeyChar is 'b' or 'B')
        {
            awaitingBankNumber = true;
            codeBox.Clear();
            e.Handled = true;
            Announce("Choose bank 0 through 9, or press R to rename a bank.");
            return;
        }
        if (awaitingBankNumber)
        {
            awaitingBankNumber = false;
            e.Handled = true;
            if (e.KeyChar is >= '0' and <= '9') SelectBank(e.KeyChar - '0');
            else if (e.KeyChar is 'r' or 'R')
            {
                awaitingRenameBankNumber = true;
                Announce($"Set {activeSet}. Choose bank 0 through 9 to rename.");
            }
            else if (e.KeyChar != (char)Keys.Escape)
            {
                System.Media.SystemSounds.Beep.Play();
                Announce($"Bank unchanged. Type B followed by 0 through 9 to select a bank, or B then R then 0 through 9 to rename one. Current bank: {activeBank}.");
            }
            return;
        }
        if (e.KeyChar is 't' or 'T')
        {
            awaitingTransferSourceBank = true;
            codeBox.Clear();
            e.Handled = true;
            Announce($"Set {activeSet}. Which bank would you like to move? Press 0 through 9.");
            return;
        }
        if (!char.IsControl(e.KeyChar) && e.KeyChar is not (>= '0' and <= '9')) { e.Handled = true; System.Media.SystemSounds.Beep.Play(); }
    }
    private void CodeChanged(object? sender, EventArgs e)
    {
        if (codeBox.Text.Length != 4) return;
        var code = codeBox.Text;
        var setNumber = activeSet;
        var bank = activeBank;
        BeginInvoke(() => { PlayCode(code, setNumber, bank); codeBox.Clear(); codeBox.Focus(); });
    }
    private void SelectBank(int bank)
    {
        settings.ActiveBank = bank;
        AppData.SaveSettings(settings);
        codeBox.Clear();
        RefreshList();
        codeBox.Focus();
        Announce($"Set {activeSet}, {activeBankDisplay} selected. Enter a four-digit code.");
    }
    private void SelectSet(int setNumber)
    {
        settings.ActiveSet = setNumber;
        AppData.SaveSettings(settings);
        CancelPendingCommands();
        codeBox.Clear();
        RefreshList();
        codeBox.Focus();
        Announce($"Set {activeSet} selected. {activeBankDisplay}. Enter a four-digit code, or type B followed by 0 through 9 to change banks.");
    }
    private void MoveBank(int sourceBank, int destinationBank)
    {
        if (sourceBank == destinationBank)
        {
            System.Media.SystemSounds.Beep.Play();
            Announce($"Transfer canceled. Source and destination are both bank {sourceBank}. Nothing was moved.");
            return;
        }
        var sourceEntries = library.Where(x => x.SetNumber == activeSet && x.Bank == sourceBank).ToList();
        if (sourceEntries.Count == 0)
        {
            System.Media.SystemSounds.Beep.Play();
            Announce($"Transfer canceled. Set {activeSet}, bank {sourceBank} has no assigned sounds.");
            return;
        }
        var destinationCount = library.Count(x => x.SetNumber == activeSet && x.Bank == destinationBank);
        var destinationName = settings.GetBankName(activeSet, destinationBank);
        if (destinationCount > 0 || !string.IsNullOrEmpty(destinationName))
        {
            System.Media.SystemSounds.Beep.Play();
            Announce($"Transfer canceled. Set {activeSet}, bank {destinationBank} is not completely empty. Nothing was moved or merged.");
            return;
        }

        var sourceName = settings.GetBankName(activeSet, sourceBank);
        foreach (var entry in sourceEntries) entry.Bank = destinationBank;
        settings.SetBankName(activeSet, destinationBank, sourceName);
        settings.SetBankName(activeSet, sourceBank, "");
        settings.ActiveBank = destinationBank;
        AppData.SaveLibrary(library);
        AppData.SaveSettings(settings);
        codeBox.Clear();
        RefreshList();
        codeBox.Focus();
        Announce($"Moved {sourceEntries.Count} sounds from set {activeSet}, bank {sourceBank}, to bank {destinationBank}. Bank {sourceBank} is now empty.");
    }
    private void CancelPendingCommands()
    {
        awaitingBankNumber = false;
        awaitingRenameBankNumber = false;
        awaitingTransferSourceBank = false;
        awaitingTransferDestinationBank = false;
        transferSourceBank = -1;
    }
    private void RenameBank(int bank)
    {
        using var form = new BankNameForm(activeSet, bank, settings.GetBankName(activeSet, bank));
        if (form.ShowDialog(this) == DialogResult.OK)
        {
            settings.SetBankName(activeSet, bank, form.BankName);
            AppData.SaveSettings(settings);
            RefreshList();
            Announce(string.IsNullOrEmpty(form.BankName) ? $"Set {activeSet}, bank {bank} name cleared." : $"Set {activeSet}, bank {bank} renamed to {form.BankName}.");
        }
        codeBox.Focus();
    }
    private void PlayCode(string code, int setNumber, int bank)
    {
        var entry = library.FirstOrDefault(x => x.SetNumber == setNumber && x.Bank == bank && x.Code == code);
        if (entry is null) { System.Media.SystemSounds.Exclamation.Play(); Announce($"Set {setNumber}, {settings.GetBankDisplayName(setNumber, bank)}, code {code} is not assigned."); return; }
        PlayEntry(entry);
    }
    private void PlayEntry(SoundEntry entry)
    {
        PlayPath(entry.FilePath, $"set {entry.SetNumber}, {settings.GetBankDisplayName(entry.SetNumber, entry.Bank)}, code {entry.Code}, {entry.Name}", "Open the Sound Library to correct it.");
    }
    private void PlayGlobal(Keys key)
    {
        var keyName = key.ToString();
        var filePath = key switch
        {
            Keys.A => settings.GlobalAFile,
            Keys.S => settings.GlobalSFile,
            Keys.D => settings.GlobalDFile,
            Keys.F => settings.GlobalFFile,
            Keys.G => settings.GlobalGFile,
            Keys.V => settings.GlobalVFile,
            Keys.Z => settings.GlobalZFile,
            Keys.X => settings.GlobalXFile,
            Keys.C => settings.GlobalCFile,
            _ => ""
        };
        if (string.IsNullOrWhiteSpace(filePath)) { System.Media.SystemSounds.Exclamation.Play(); Announce($"Global key {keyName} has no sound assigned. Press Control+G to assign one."); return; }
        PlayPath(filePath, $"global key {keyName}", "Press Control+G to correct the assignment.");
    }
    private void PlayPath(string filePath, string description, string correction)
    {
        if (!File.Exists(filePath)) { System.Media.SystemSounds.Hand.Play(); Announce($"File missing for {description}. {correction}"); return; }
        try { player.Play(filePath, settings); lastPlayedPath = filePath; lastPlayedDescription = description; }
        catch (Exception ex) { Announce($"Could not play {description}. {ex.Message}"); }
    }
    private void PlaySelected() { if (sounds.SelectedItem is SoundEntry entry) PlayEntry(entry); }
    private void StopPlayback() { player.Stop(); Announce("Playback stopped."); codeBox.Focus(); }
    private void StopPlaybackSilently() => player.Stop();
    private void Replay()
    {
        CancelPendingCommands();
        if (lastPlayedPath is null || lastPlayedDescription is null) Announce("There is no previous sound to replay.");
        else PlayPath(lastPlayedPath, lastPlayedDescription, "Open its assignment settings to correct it.");
        codeBox.Focus();
    }
    private void OpenLibrary()
    {
        CancelPendingCommands();
        using var form = new LibraryForm(library, activeSet, activeBank, settings.BankNames);
        if (form.ShowDialog(this) == DialogResult.OK)
        {
            library = form.Entries;
            settings.ActiveSet = form.SelectedSet;
            settings.ActiveBank = form.SelectedBank;
            settings.BankNames = new Dictionary<string, string>(form.BankNames);
            AppData.SaveLibrary(library);
            AppData.SaveSettings(settings);
            RefreshList();
            Announce($"Sound Library saved. Set {activeSet}, {activeBankDisplay}; {library.Count(x => x.SetNumber == activeSet && x.Bank == activeBank)} sounds assigned in this bank.");
        }
        codeBox.Focus();
    }
    private void OpenAudioSettings()
    {
        CancelPendingCommands();
        using var form = new AudioSettingsForm(settings);
        if (form.ShowDialog(this) == DialogResult.OK) { settings = form.Value; AppData.SaveSettings(settings); Announce("Audio output settings saved."); }
        codeBox.Focus();
    }
    private void OpenGlobalSoundSettings()
    {
        CancelPendingCommands();
        using var form = new GlobalSoundSettingsForm(settings);
        if (form.ShowDialog(this) == DialogResult.OK) { settings = form.Value; AppData.SaveSettings(settings); Announce("Global A, S, D, F, G, V, Z, X, and C sound assignments saved."); }
        codeBox.Focus();
    }
    private void RefreshList() { bankLabel.Text = $"Current set: {activeSet} of 2. {activeBankDisplay}. Press F2 or F3 to change sets; type B then 0 through 9 to change banks."; codeBox.AccessibleName = $"Four-digit sound code, set {activeSet}, {activeBankDisplay}"; sounds.AccessibleName = $"Available sounds in set {activeSet}, {activeBankDisplay}"; sounds.DataSource = null; sounds.DataSource = library.Where(x => x.SetNumber == activeSet && x.Bank == activeBank).OrderBy(x => x.Code).ToList(); }
    private void GlobalKeys(object? sender, KeyEventArgs e)
    {
        if (!e.Control && !e.Alt && !e.Shift && e.KeyCode is Keys.A or Keys.S or Keys.D or Keys.F or Keys.G or Keys.V or Keys.Z or Keys.X or Keys.C) { CancelPendingCommands(); codeBox.Clear(); PlayGlobal(e.KeyCode); e.Handled = true; e.SuppressKeyPress = true; }
        else if (e.KeyCode == Keys.Escape) { CancelPendingCommands(); StopPlayback(); e.Handled = true; }
        else if (e.KeyCode == Keys.Space) { CancelPendingCommands(); StopPlaybackSilently(); e.Handled = true; e.SuppressKeyPress = true; }
        else if (e.Control && e.KeyCode == Keys.R) { Replay(); e.Handled = true; e.SuppressKeyPress = true; }
        else if (e.Control && e.KeyCode == Keys.L) { OpenLibrary(); e.Handled = true; e.SuppressKeyPress = true; }
        else if (e.Control && e.KeyCode == Keys.G) { OpenGlobalSoundSettings(); e.Handled = true; e.SuppressKeyPress = true; }
        else if (e.KeyCode == Keys.Enter && sounds.Focused) { PlaySelected(); e.Handled = true; }
        else if (e.KeyCode == Keys.F2) { SelectSet(1); e.Handled = true; }
        else if (e.KeyCode == Keys.F3) { SelectSet(2); e.Handled = true; }
        else if (e.KeyCode == Keys.F1) { ShowHelp(); e.Handled = true; }
    }
    private void ShowHelp() => MessageBox.Show(this, "F2: switch to sound set 1.\nF3: switch to sound set 2.\nType B followed by 0 through 9 to select a bank inside the active set.\nType B, then R, then 0 through 9 to open the rename screen for that bank in the active set.\nType T, then the source bank number, then the destination bank number to move an entire bank. The destination must be completely empty, so sounds are never merged or overwritten. The bank name moves with its sounds.\nType a four-digit code from 0000 through 9999 to play the sound in that set and bank.\nPress A, S, D, F, G, V, Z, X, or C to immediately play its global sound. These assignments work in both sets and every bank. Press Control+G to assign or change them.\nSpacebar: stop playback silently.\nEscape: stop playback and announce that it stopped.\nControl+R: replay the last sound.\nControl+L: manage the Sound Library and bank names.\nAlt+O: choose meeting and headphone outputs.\nF1: show this help.\n\nIn the sound list, press Enter or double-click to test the selected sound.", "Keyboard commands", MessageBoxButtons.OK, MessageBoxIcon.Information);
    private void Announce(string message)
    {
        status.Text = message;
        try { status.AccessibilityObject.RaiseAutomationNotification(AutomationNotificationKind.ActionCompleted, AutomationNotificationProcessing.MostRecent, message); } catch { }
    }
}
