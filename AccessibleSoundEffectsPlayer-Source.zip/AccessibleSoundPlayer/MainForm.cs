using System.Windows.Forms.Automation;

namespace AccessibleSoundPlayer;

public sealed class MainForm : Form
{
    private readonly TextBox codeBox = new() { MaxLength = 3, AccessibleName = "Three-digit sound code", Font = new Font("Segoe UI", 22), Width = 180 };
    private readonly Label status = new() { AutoSize = true, AccessibleName = "Player status" };
    private readonly Label bankLabel = new() { AutoSize = true };
    private readonly ListBox sounds = new() { AccessibleName = "Available sounds", IntegralHeight = false };
    private readonly AudioPlayer player = new();
    private List<SoundEntry> library = AppData.LoadLibrary();
    private AppSettings settings = AppData.LoadSettings();
    private SoundEntry? lastPlayed;
    private bool awaitingBankNumber;
    private int activeBank => Math.Clamp(settings.ActiveBank, 1, 9);

    public MainForm()
    {
        Text = "Accessible Sound Effects Player";
        AccessibleName = Text;
        StartPosition = FormStartPosition.CenterScreen;
        MinimumSize = new Size(650, 480);
        KeyPreview = true;
        var menu = BuildMenu();
        var codeLabel = new Label { Text = "Sound code (3 digits):", AutoSize = true, AccessibleName = "Sound code, three digits" };
        var instruction = new Label { Text = "Type three digits. The assigned sound plays automatically.", AutoSize = true };
        var top = new FlowLayoutPanel { Dock = DockStyle.Top, AutoSize = true, FlowDirection = FlowDirection.TopDown, Padding = new Padding(12), WrapContents = false };
        top.Controls.Add(instruction); top.Controls.Add(bankLabel); top.Controls.Add(codeLabel); top.Controls.Add(codeBox); top.Controls.Add(status);
        sounds.Dock = DockStyle.Fill;
        Controls.Add(sounds); Controls.Add(top); Controls.Add(menu);
        MainMenuStrip = menu;
        codeBox.KeyPress += CodeKeyPress;
        codeBox.TextChanged += CodeChanged;
        sounds.DoubleClick += (_, _) => PlaySelected();
        KeyDown += GlobalKeys;
        Shown += (_, _) => { RefreshList(); codeBox.Focus(); Announce(library.Count == 0 ? $"Bank {activeBank}. No sounds assigned. Press Control+L to open the Sound Library." : $"Bank {activeBank} ready. Enter three digits, or type B followed by 1 through 9 to switch banks."); };
        FormClosing += (_, _) => player.Dispose();
    }

    private MenuStrip BuildMenu()
    {
        var menu = new MenuStrip();
        var file = new ToolStripMenuItem("&File");
        ((ToolStripMenuItem)file.DropDownItems.Add("&Sound Library...", null, (_, _) => OpenLibrary())).ShortcutKeys = Keys.Control | Keys.L;
        ((ToolStripMenuItem)file.DropDownItems.Add("&Exit", null, (_, _) => Close())).ShortcutKeys = Keys.Alt | Keys.F4;
        var playback = new ToolStripMenuItem("&Playback");
        playback.DropDownItems.Add("&Stop", null, (_, _) => StopPlayback());
        ((ToolStripMenuItem)playback.DropDownItems.Add("&Replay last sound", null, (_, _) => Replay())).ShortcutKeys = Keys.Control | Keys.R;
        var options = new ToolStripMenuItem("&Options");
        ((ToolStripMenuItem)options.DropDownItems.Add("&Audio outputs...", null, (_, _) => OpenAudioSettings())).ShortcutKeys = Keys.Alt | Keys.O;
        var help = new ToolStripMenuItem("&Help");
        ((ToolStripMenuItem)help.DropDownItems.Add("&Keyboard commands", null, (_, _) => ShowHelp())).ShortcutKeys = Keys.F1;
        menu.Items.AddRange([file, playback, options, help]);
        return menu;
    }

    private void CodeKeyPress(object? sender, KeyPressEventArgs e)
    {
        if (e.KeyChar is 'b' or 'B')
        {
            awaitingBankNumber = true;
            codeBox.Clear();
            e.Handled = true;
            Announce("Choose bank 1 through 9.");
            return;
        }
        if (awaitingBankNumber)
        {
            awaitingBankNumber = false;
            e.Handled = true;
            if (e.KeyChar is >= '1' and <= '9') SelectBank(e.KeyChar - '0');
            else if (e.KeyChar != (char)Keys.Escape)
            {
                System.Media.SystemSounds.Beep.Play();
                Announce($"Bank unchanged. Type B followed by 1 through 9. Current bank: {activeBank}.");
            }
            return;
        }
        if (!char.IsControl(e.KeyChar) && e.KeyChar is not (>= '0' and <= '9')) { e.Handled = true; System.Media.SystemSounds.Beep.Play(); }
    }
    private void CodeChanged(object? sender, EventArgs e)
    {
        if (codeBox.Text.Length != 3) return;
        var code = codeBox.Text;
        var bank = activeBank;
        BeginInvoke(() => { PlayCode(code, bank); codeBox.Clear(); codeBox.Focus(); });
    }
    private void SelectBank(int bank)
    {
        settings.ActiveBank = bank;
        AppData.SaveSettings(settings);
        codeBox.Clear();
        RefreshList();
        codeBox.Focus();
        Announce($"Bank {bank} selected. Enter a three-digit code.");
    }
    private void PlayCode(string code, int bank)
    {
        var entry = library.FirstOrDefault(x => x.Bank == bank && x.Code == code);
        if (entry is null) { System.Media.SystemSounds.Exclamation.Play(); Announce($"Bank {bank}, code {code} is not assigned."); return; }
        PlayEntry(entry);
    }
    private void PlayEntry(SoundEntry entry)
    {
        if (!File.Exists(entry.FilePath)) { System.Media.SystemSounds.Hand.Play(); Announce($"File missing for bank {entry.Bank}, code {entry.Code}, {entry.Name}. Open the Sound Library to correct it."); return; }
        try { player.Play(entry.FilePath, settings); lastPlayed = entry; Announce($"Playing bank {entry.Bank}, code {entry.Code}, {entry.Name}, category {entry.Category}."); }
        catch (Exception ex) { Announce($"Could not play bank {entry.Bank}, code {entry.Code}. {ex.Message}"); }
    }
    private void PlaySelected() { if (sounds.SelectedItem is SoundEntry entry) PlayEntry(entry); }
    private void StopPlayback() { player.Stop(); Announce("Playback stopped."); codeBox.Focus(); }
    private void Replay() { if (lastPlayed is null) Announce("There is no previous sound to replay."); else PlayEntry(lastPlayed); codeBox.Focus(); }
    private void OpenLibrary()
    {
        using var form = new LibraryForm(library, activeBank);
        if (form.ShowDialog(this) == DialogResult.OK) { library = form.Entries; AppData.SaveLibrary(library); SelectBank(form.SelectedBank); Announce($"Sound Library saved. Bank {activeBank} selected; {library.Count(x => x.Bank == activeBank)} sounds assigned in this bank."); }
        codeBox.Focus();
    }
    private void OpenAudioSettings()
    {
        using var form = new AudioSettingsForm(settings);
        if (form.ShowDialog(this) == DialogResult.OK) { settings = form.Value; AppData.SaveSettings(settings); Announce("Audio output settings saved."); }
        codeBox.Focus();
    }
    private void RefreshList() { bankLabel.Text = $"Current bank: {activeBank} of 9 (type B then 1 through 9 to change)"; codeBox.AccessibleName = $"Three-digit sound code, bank {activeBank}"; sounds.AccessibleName = $"Available sounds in bank {activeBank}"; sounds.DataSource = null; sounds.DataSource = library.Where(x => x.Bank == activeBank).OrderBy(x => x.Code).ToList(); }
    private void GlobalKeys(object? sender, KeyEventArgs e)
    {
        if (e.KeyCode == Keys.Escape) { awaitingBankNumber = false; StopPlayback(); e.Handled = true; }
        else if (e.Control && e.KeyCode == Keys.R) { Replay(); e.Handled = true; }
        else if (e.Control && e.KeyCode == Keys.L) { OpenLibrary(); e.Handled = true; }
        else if (e.KeyCode == Keys.Enter && sounds.Focused) { PlaySelected(); e.Handled = true; }
        else if (e.KeyCode == Keys.F1) { ShowHelp(); e.Handled = true; }
    }
    private void ShowHelp() => MessageBox.Show(this, "In the code box, type B followed by 1 through 9 to select a bank. The selected bank stays active until you switch again.\nType a three-digit code to play the sound in that bank.\nEscape: stop playback.\nControl+R: replay the last sound.\nControl+L: manage the Sound Library.\nAlt+O: choose meeting and headphone outputs.\nF1: show this help.\n\nIn the sound list, press Enter or double-click to test the selected sound.", "Keyboard commands", MessageBoxButtons.OK, MessageBoxIcon.Information);
    private void Announce(string message)
    {
        status.Text = message;
        try { status.AccessibilityObject.RaiseAutomationNotification(AutomationNotificationKind.ActionCompleted, AutomationNotificationProcessing.MostRecent, message); } catch { }
    }
}
