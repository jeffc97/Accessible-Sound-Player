using System.Windows.Forms.Automation;

namespace AccessibleSoundPlayer;

public sealed class MainForm : Form
{
    private readonly TextBox codeBox = new() { MaxLength = 3, AccessibleName = "Three-digit sound code", Font = new Font("Segoe UI", 22), Width = 180 };
    private readonly Label status = new() { AutoSize = true, AccessibleName = "Player status" };
    private readonly ListBox sounds = new() { AccessibleName = "Available sounds", IntegralHeight = false };
    private readonly AudioPlayer player = new();
    private List<SoundEntry> library = AppData.LoadLibrary();
    private AppSettings settings = AppData.LoadSettings();
    private SoundEntry? lastPlayed;

    public MainForm()
    {
        Text = "Accessible Sound Effects Player";
        AccessibleName = Text;
        StartPosition = FormStartPosition.CenterScreen;
        MinimumSize = new Size(650, 480);
        KeyPreview = true;
        var menu = BuildMenu();
        var codeLabel = new Label { Text = "Sound code (3 digits):", AutoSize = true, AccessibleName = "Sound code, three digits" };
        var instruction = new Label { Text = "Type three digits. The assigned sound plays automatically.", AutoSize = true };
        var top = new FlowLayoutPanel { Dock = DockStyle.Top, AutoSize = true, FlowDirection = FlowDirection.TopDown, Padding = new Padding(12), WrapContents = false };
        top.Controls.Add(instruction); top.Controls.Add(codeLabel); top.Controls.Add(codeBox); top.Controls.Add(status);
        sounds.Dock = DockStyle.Fill;
        Controls.Add(sounds); Controls.Add(top); Controls.Add(menu);
        MainMenuStrip = menu;
        codeBox.KeyPress += CodeKeyPress;
        codeBox.TextChanged += CodeChanged;
        sounds.DoubleClick += (_, _) => PlaySelected();
        KeyDown += GlobalKeys;
        Shown += (_, _) => { RefreshList(); codeBox.Focus(); Announce(library.Count == 0 ? "No sounds assigned. Press Control+L to open the Sound Library." : "Ready. Enter a three-digit code."); };
        FormClosing += (_, _) => player.Dispose();
    }

    private MenuStrip BuildMenu()
    {
        var menu = new MenuStrip();
        var file = new ToolStripMenuItem("&File");
        ((ToolStripMenuItem)file.DropDownItems.Add("&Sound Library...", null, (_, _) => OpenLibrary())).ShortcutKeys = Keys.Control | Keys.L;
        ((ToolStripMenuItem)file.DropDownItems.Add("&Exit", null, (_, _) => Close())).ShortcutKeys = Keys.Alt | Keys.F4;
        var playback = new ToolStripMenuItem("&Playback");
        ((ToolStripMenuItem)playback.DropDownItems.Add("&Stop", null, (_, _) => StopPlayback())).ShortcutKeys = Keys.Escape;
        ((ToolStripMenuItem)playback.DropDownItems.Add("&Replay last sound", null, (_, _) => Replay())).ShortcutKeys = Keys.Control | Keys.R;
        var options = new ToolStripMenuItem("&Options");
        ((ToolStripMenuItem)options.DropDownItems.Add("&Audio outputs...", null, (_, _) => OpenAudioSettings())).ShortcutKeys = Keys.Alt | Keys.O;
        var help = new ToolStripMenuItem("&Help");
        ((ToolStripMenuItem)help.DropDownItems.Add("&Keyboard commands", null, (_, _) => ShowHelp())).ShortcutKeys = Keys.F1;
        menu.Items.AddRange([file, playback, options, help]);
        return menu;
    }

    private void CodeKeyPress(object? sender, KeyPressEventArgs e)
    {
        if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar)) { e.Handled = true; System.Media.SystemSounds.Beep.Play(); }
    }
    private void CodeChanged(object? sender, EventArgs e)
    {
        if (codeBox.Text.Length != 3) return;
        var code = codeBox.Text;
        BeginInvoke(() => { PlayCode(code); codeBox.Clear(); codeBox.Focus(); });
    }
    private void PlayCode(string code)
    {
        var entry = library.FirstOrDefault(x => x.Code == code);
        if (entry is null) { System.Media.SystemSounds.Exclamation.Play(); Announce($"Code {code} is not assigned."); return; }
        if (!File.Exists(entry.FilePath)) { System.Media.SystemSounds.Hand.Play(); Announce($"File missing for {code}, {entry.Name}. Open the Sound Library to correct it."); return; }
        try { player.Play(entry.FilePath, settings); lastPlayed = entry; Announce($"Playing {code}, {entry.Name}, category {entry.Category}."); }
        catch (Exception ex) { Announce($"Could not play {code}. {ex.Message}"); }
    }
    private void PlaySelected() { if (sounds.SelectedItem is SoundEntry entry) PlayCode(entry.Code); }
    private void StopPlayback() { player.Stop(); Announce("Playback stopped."); codeBox.Focus(); }
    private void Replay() { if (lastPlayed is null) Announce("There is no previous sound to replay."); else PlayCode(lastPlayed.Code); codeBox.Focus(); }
    private void OpenLibrary()
    {
        using var form = new LibraryForm(library);
        if (form.ShowDialog(this) == DialogResult.OK) { library = form.Entries; AppData.SaveLibrary(library); RefreshList(); Announce($"Sound Library saved. {library.Count} sounds assigned."); }
        codeBox.Focus();
    }
    private void OpenAudioSettings()
    {
        using var form = new AudioSettingsForm(settings);
        if (form.ShowDialog(this) == DialogResult.OK) { settings = form.Value; AppData.SaveSettings(settings); Announce("Audio output settings saved."); }
        codeBox.Focus();
    }
    private void RefreshList() { sounds.DataSource = null; sounds.DataSource = library.OrderBy(x => x.Code).ToList(); }
    private void GlobalKeys(object? sender, KeyEventArgs e)
    {
        if (e.KeyCode == Keys.Escape) { StopPlayback(); e.Handled = true; }
        else if (e.Control && e.KeyCode == Keys.R) { Replay(); e.Handled = true; }
        else if (e.Control && e.KeyCode == Keys.L) { OpenLibrary(); e.Handled = true; }
        else if (e.KeyCode == Keys.Enter && sounds.Focused) { PlaySelected(); e.Handled = true; }
        else if (e.KeyCode == Keys.F1) { ShowHelp(); e.Handled = true; }
    }
    private void ShowHelp() => MessageBox.Show(this, "Type a three-digit code: play assigned sound automatically.\nEscape: stop playback.\nControl+R: replay the last sound.\nControl+L: manage the Sound Library.\nAlt+O: choose meeting and headphone outputs.\nF1: show this help.\n\nIn the sound list, press Enter or double-click to test the selected sound.", "Keyboard commands", MessageBoxButtons.OK, MessageBoxIcon.Information);
    private void Announce(string message)
    {
        status.Text = message;
        try { status.AccessibilityObject.RaiseAutomationNotification(AutomationNotificationKind.ActionCompleted, AutomationNotificationProcessing.MostRecent, message); } catch { }
    }
}
