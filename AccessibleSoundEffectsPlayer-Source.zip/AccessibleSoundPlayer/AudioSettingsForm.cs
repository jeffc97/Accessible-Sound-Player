using NAudio.Wave;

namespace AccessibleSoundPlayer;

public sealed class AudioSettingsForm : Form
{
    private readonly CheckBox meetingEnabled = new() { Text = "Send sound to the &meeting output", AutoSize = true };
    private readonly ComboBox meeting = new() { DropDownStyle = ComboBoxStyle.DropDownList, Width = 360, AccessibleName = "Meeting output device" };
    private readonly CheckBox headphonesEnabled = new() { Text = "Send sound to my &headphones", AutoSize = true };
    private readonly ComboBox headphones = new() { DropDownStyle = ComboBoxStyle.DropDownList, Width = 360, AccessibleName = "Headphone output device" };
    private readonly TrackBar volume = new() { Minimum = 0, Maximum = 100, TickFrequency = 10, AccessibleName = "Playback volume percent" };
    private readonly IReadOnlyList<(int Number, string Name)> devices;
    private readonly int activeBank;
    private readonly string globalZFile;
    private readonly string globalXFile;
    private readonly string globalCFile;
    public AppSettings Value => new() { ActiveBank = activeBank, GlobalZFile = globalZFile, GlobalXFile = globalXFile, GlobalCFile = globalCFile, UseMeeting = meetingEnabled.Checked, UseHeadphones = headphonesEnabled.Checked, MeetingDevice = devices[meeting.SelectedIndex].Number, HeadphoneDevice = devices[headphones.SelectedIndex].Number, Volume = volume.Value / 100f };
    public AudioSettingsForm(AppSettings current)
    {
        activeBank = current.ActiveBank;
        globalZFile = current.GlobalZFile;
        globalXFile = current.GlobalXFile;
        globalCFile = current.GlobalCFile;
        Text = "Audio output settings"; StartPosition = FormStartPosition.CenterParent; AutoSize = true; AutoSizeMode = AutoSizeMode.GrowAndShrink;
        devices = AudioPlayer.GetDevices(); foreach (var d in devices) { meeting.Items.Add(d.Name); headphones.Items.Add(d.Name); }
        meeting.SelectedIndex = IndexFor(current.MeetingDevice); headphones.SelectedIndex = IndexFor(current.HeadphoneDevice); meetingEnabled.Checked = current.UseMeeting; headphonesEnabled.Checked = current.UseHeadphones; volume.Value = Math.Clamp((int)(current.Volume * 100), 0, 100);
        var panel = new FlowLayoutPanel { FlowDirection = FlowDirection.TopDown, AutoSize = true, Padding = new Padding(12), WrapContents = false };
        panel.Controls.Add(new Label { Text = "Choose the device your meeting receives, such as a virtual audio cable or mixer.", AutoSize = true }); panel.Controls.Add(meetingEnabled); panel.Controls.Add(meeting);
        panel.Controls.Add(headphonesEnabled); panel.Controls.Add(headphones); panel.Controls.Add(new Label { Text = "&Volume:", AutoSize = true }); panel.Controls.Add(volume);
        var buttons = new FlowLayoutPanel { AutoSize = true }; buttons.Controls.Add(new Button { Text = "&OK", DialogResult = DialogResult.OK, AutoSize = true }); buttons.Controls.Add(new Button { Text = "Cancel", DialogResult = DialogResult.Cancel, AutoSize = true }); panel.Controls.Add(buttons); Controls.Add(panel);
        AcceptButton = (Button)buttons.Controls[0]; CancelButton = (Button)buttons.Controls[1];
    }
    private int IndexFor(int number) { for (var i = 0; i < devices.Count; i++) if (devices[i].Number == number) return i; return 0; }
}
