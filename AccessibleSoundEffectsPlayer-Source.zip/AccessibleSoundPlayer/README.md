# Accessible Sound Effects Player

A keyboard-first Windows soundboard designed for JAWS and virtual audio trivia. Type a three-digit code and the assigned sound plays immediately through one or two selected output devices.

## Keyboard commands

- Type three digits: play the assigned sound and clear the code automatically.
- Escape: stop playback.
- Control+R: replay the last sound.
- Control+L: open the Sound Library.
- Alt+O: choose meeting and headphone outputs.
- F1: show keyboard help.

## First-time setup with JAWS

1. Open **Options, Audio outputs**, or press Alt+O.
2. Check **Send sound to the meeting output** and choose the virtual cable or mixer input that Zoom receives.
3. Check **Send sound to my headphones** and choose your headphones.
4. Press Enter on OK.
5. Press Control+L to open the Sound Library.
6. Use **Add** for one sound or **Import folder** for a group. Folder import uses the folder name as the category and assigns the next unused three-digit codes.
7. Review or edit the assignments, then activate **Save and close**.

Keep the source audio files in a permanent folder. The library points to those files; it does not copy or delete them.

## Supported files

WAV and MP3 are recommended. Playback also accepts formats supported by Windows Media Foundation, including common WMA, AAC, M4A, AIFF, and FLAC files.

## Building the installer

The included GitHub Actions workflow produces a self-contained 64-bit Windows installer. Put this folder in a GitHub repository, open the Actions tab, run **Build Windows installer**, and download the resulting artifact. The target PC does not need .NET installed.
