# Accessible Sound Effects Player

A keyboard-first Windows soundboard designed for JAWS and virtual audio trivia. Type B followed by 1 through 9 in the main code box to select a bank; then type a four-digit code from 0000 through 9999 and the assigned sound in that bank plays immediately through one or two selected output devices. The selected bank remains active until you switch again, even after restarting the app. Z, X, and C can each have a separate persistent global sound that works in every bank.

## Keyboard commands

- In the main code box, type B1 through B9: switch to bank 1 through 9. JAWS announces the selected bank.
- Type four digits from 0000 through 9999: silently play the assigned sound in the selected bank and clear the code automatically. Unassigned codes still receive a spoken alert.
- Z, X, or C: silently play the sound assigned to that global key immediately. Missing assignments, missing files, and playback errors are announced.
- Control+G: assign or change the global Z, X, and C sounds.
- Escape: stop playback.
- Control+R: replay the last sound.
- Control+L: open the Sound Library.
- Alt+O: choose meeting and headphone outputs.
- F1: show keyboard help.

## First-time setup with JAWS

1. Open **Options, Audio outputs**, or press Alt+O.
2. Check **Send sound to the meeting output** and choose the virtual cable or mixer input that Zoom receives.
3. Check **Send sound to my headphones** and choose your headphones.
4. Press Enter on OK.
5. Press Control+L to open the Sound Library.
6. Select the bank to manage at the top of the Sound Library. Use **Add** for one sound or **Import folder** for a group. Folder import uses the folder name as the category and assigns the next unused four-digit codes in that bank.
7. Review or edit the assignments, then activate **Save and close**.
8. Press Control+G to choose the three sounds assigned globally to Z, X, and C. These assignments are independent of the selected bank and remain saved after restarting the app.

Keep the source audio files in a permanent folder. The library points to those files; it does not copy or delete them.

Existing libraries are assigned to bank 1 automatically. Existing three-digit assignments are preserved by adding a zero at the beginning, so code 042 becomes 0042. A four-digit code can be used once per bank, so code 0042 can play different sounds in banks 1 and 2. Use the bank selector in the Sound Library to add, edit, or remove sounds in each bank; **Save and close** saves changes across all banks.

## Supported files

WAV and MP3 are recommended. Playback also accepts formats supported by Windows Media Foundation, including common WMA, AAC, M4A, AIFF, and FLAC files.

## Building the installer

The included GitHub Actions workflow produces a self-contained 64-bit Windows installer. Put this folder in a GitHub repository, open the Actions tab, run **Build Windows installer**, and download the resulting artifact. The target PC does not need .NET installed.
