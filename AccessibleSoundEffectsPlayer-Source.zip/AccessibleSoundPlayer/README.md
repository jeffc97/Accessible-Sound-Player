# Accessible Sound Effects Player

A keyboard-first Windows soundboard designed for JAWS and virtual audio trivia. It has two completely independent sound sets, each containing nine banks with four-digit codes from 0000 through 9999. Every bank can have an optional name. The active set and bank remain selected after restarting the app. A, S, D, F, G, V, Z, X, and C can each have a separate persistent global sound that works across both sets and all banks.

## Keyboard commands

- F2: switch to sound set 1.
- F3: switch to sound set 2.
- In the main code box, type B1 through B9: switch to bank 1 through 9 inside the active set. JAWS announces the set, bank number, and optional bank name.
- Type B, then R, then 1 through 9: open the bank-name screen for that bank in the currently active set. Saving or clearing the name is announced by JAWS.
- Type four digits from 0000 through 9999: silently play the assigned sound in the selected bank and clear the code automatically. Unassigned codes still receive a spoken alert.
- A, S, D, F, G, V, Z, X, or C: silently play the sound assigned to that global key immediately. Missing assignments, missing files, and playback errors are announced.
- Control+G: assign or change all nine global sound hot keys.
- Spacebar: immediately stop playback without a spoken announcement.
- Escape: stop playback and announce that it stopped.
- Control+R: replay the last sound.
- Control+L: open the Sound Library.
- Alt+O: choose meeting and headphone outputs.
- F1: show keyboard help.

## First-time setup with JAWS

1. Open **Options, Audio outputs**, or press Alt+O.
2. Check **Send sound to the meeting output** and choose the virtual cable or mixer input that Zoom receives.
3. Check **Send sound to my headphones** and choose your headphones.
4. Press Enter on OK.
5. Press Control+L to open the Sound Library.
6. Select **Set 1** or **Set 2**, then select the bank to manage at the top of the Sound Library.
7. Activate **Rename bank** to give that bank an optional name. Names are separate for every bank in both sets. Clear the name to return to the default Bank 1 through Bank 9 label.
8. Use **Add** for one sound or **Import folder** for a group. Folder import uses the folder name as the category and assigns the next unused four-digit codes in the selected set and bank.
9. Review or edit the assignments, then activate **Save and close**.
10. Press Control+G to choose the nine sounds assigned globally to A, S, D, F, G, V, Z, X, and C. These assignments work in both sets and every bank and remain saved after restarting the app.

Keep the source audio files in a permanent folder. The library points to those files; it does not copy or delete them.

Existing sounds remain in Set 1 automatically. Existing three-digit assignments are preserved by adding a zero at the beginning, so code 042 becomes 0042. The same four-digit code can play a different sound in every bank and set. Set 2 begins empty.

## Supported files

WAV and MP3 are recommended. Playback also accepts formats supported by Windows Media Foundation, including common WMA, AAC, M4A, AIFF, and FLAC files.

## Building the installer

The included GitHub Actions workflow produces a self-contained 64-bit Windows installer. Put this folder in a GitHub repository, open the Actions tab, run **Build Windows installer**, and download the resulting artifact. The target PC does not need .NET installed.
